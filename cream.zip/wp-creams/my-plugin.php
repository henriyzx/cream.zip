<?php
/**
 * Plugin Name: My Plugin
 * Plugin URI:  https://example.com/my-plugin
 * Description: Deskripsi singkat plugin Anda di sini.
 * Version:     1.0.0
 * Author:      Nama Anda
 * Author URI:  https://example.com
 * License:     GPL-2.0+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: my-plugin
 * Domain Path: /languages
 */

// Keamanan: cegah akses langsung ke file ini
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ============================================================
// Konstanta Plugin
// ============================================================
define( 'MY_PLUGIN_VERSION', '1.0.0' );
define( 'MY_PLUGIN_FILE',    __FILE__ );
define( 'MY_PLUGIN_DIR',     plugin_dir_path( __FILE__ ) );
define( 'MY_PLUGIN_URL',     plugin_dir_url( __FILE__ ) );

// ============================================================
// Aktivasi & Deaktivasi
// ============================================================

register_activation_hook( __FILE__, 'my_plugin_activate' );
function my_plugin_activate() {
    // Jalankan saat plugin diaktifkan
    // Contoh: buat tabel database, set opsi default, dll.
}

register_deactivation_hook( __FILE__, 'my_plugin_deactivate' );
function my_plugin_deactivate() {
    // Jalankan saat plugin dinonaktifkan
    // Contoh: hapus cron job, bersihkan cache, dll.
}

// ============================================================
// Muat file pendukung (opsional)
// ============================================================
// require_once MY_PLUGIN_DIR . 'includes/class-my-plugin.php';
// require_once MY_PLUGIN_DIR . 'admin/admin.php';

// ============================================================
// Hook & Filter utama
// ============================================================

add_action( 'init', 'my_plugin_init' );
function my_plugin_init() {
    // Kode inisialisasi plugin Anda di sini
}

// Daftarkan script / style (frontend)
add_action( 'wp_enqueue_scripts', 'my_plugin_enqueue_scripts' );
function my_plugin_enqueue_scripts() {
    // wp_enqueue_style( 'my-plugin-style', MY_PLUGIN_URL . 'assets/css/style.css', [], MY_PLUGIN_VERSION );
    // wp_enqueue_script( 'my-plugin-script', MY_PLUGIN_URL . 'assets/js/script.js', ['jquery'], MY_PLUGIN_VERSION, true );
}

// Daftarkan script / style (admin)
add_action( 'admin_enqueue_scripts', 'my_plugin_admin_enqueue_scripts' );
function my_plugin_admin_enqueue_scripts() {
    // wp_enqueue_style( 'my-plugin-admin-style', MY_PLUGIN_URL . 'assets/css/admin.css', [], MY_PLUGIN_VERSION );
}

// Tambahkan menu di dashboard admin (opsional)
add_action( 'admin_menu', 'my_plugin_admin_menu' );
function my_plugin_admin_menu() {
    // add_menu_page(
    //     'My Plugin',          // Judul halaman
    //     'My Plugin',          // Label menu
    //     'manage_options',     // Kapabilitas
    //     'my-plugin',          // Slug
    //     'my_plugin_admin_page', // Callback
    //     'dashicons-admin-plugins',
    //     90
    // );
}

function my_plugin_admin_page() {
    echo '<div class="wrap"><h1>My Plugin</h1><p>Halaman pengaturan plugin Anda.</p></div>';
}
